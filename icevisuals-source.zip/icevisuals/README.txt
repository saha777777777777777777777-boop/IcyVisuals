Ice Visuals для Minecraft 1.21.11 (Fabric)

Сборка (Windows):
1. Установите JDK 21.
2. Распакуйте архив и запустите build.bat (нужен интернет).
3. Готовый мод: build\libs\icevisuals-1.0.0.jar (не тот, что с -sources).

Установка: поставьте Fabric Loader для 1.21.11, положите в папку mods
этот jar и Fabric API.
