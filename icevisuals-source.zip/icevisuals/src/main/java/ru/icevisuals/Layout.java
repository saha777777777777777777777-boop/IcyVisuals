package ru.icevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;

// Сдвиг блоков HUD относительно стандартного места
final class Layout {
    // стандартные элементы игры тоже можно двигать
    static void registerVanilla() {
        move("hotbar", VanillaHudElements.HOTBAR);
        move("health", VanillaHudElements.HEALTH_BAR);
        move("health", VanillaHudElements.ARMOR_BAR);
        move("food", VanillaHudElements.FOOD_BAR);
        move("food", VanillaHudElements.AIR_BAR);
        move("food", VanillaHudElements.MOUNT_HEALTH);
        move("xp", VanillaHudElements.INFO_BAR);
        move("xp", VanillaHudElements.EXPERIENCE_LEVEL);
        move("icons", VanillaHudElements.STATUS_EFFECTS);
        move("boss", VanillaHudElements.BOSS_BAR);
        move("score", VanillaHudElements.SCOREBOARD);
        move("chat", VanillaHudElements.CHAT);
    }

    private static void move(String key, Identifier element) {
        HudElementRegistry.replaceElement(element, original -> (g, delta) -> {
            push(g, key);
            original.render(g, delta);
            pop(g);
        });
    }

    static void push(GuiGraphics g, String key) {
        g.pose().pushMatrix();
        g.pose().translate(Settings.number("pos." + key + ".x", 0), Settings.number("pos." + key + ".y", 0));
    }

    static void pop(GuiGraphics g) {
        g.pose().popMatrix();
    }
}
