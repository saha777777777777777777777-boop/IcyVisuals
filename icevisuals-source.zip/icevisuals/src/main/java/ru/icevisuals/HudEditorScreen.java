package ru.icevisuals;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

// Перетаскивание блоков HUD мышкой или пальцем
public class HudEditorScreen extends Screen {
    private static final String[] KEYS = {"info", "effects", "armor", "inventory", "cooldowns", "timers",
            "hotbar", "health", "food", "xp", "icons", "boss", "score", "chat"};
    private static final String[] NAMES = {"Info Panel", "Potion Timer", "Armor HUD", "Inventory", "Cooldowns", "Trap Timer",
            "Hotbar", "Health", "Food", "XP", "Effects", "Boss Bar", "Scoreboard", "Chat"};

    private final Screen parent;
    private String dragged;
    private int grabX, grabY;
    private boolean wasDown = true;

    public HudEditorScreen(Screen parent) {
        super(Component.literal("Двигать HUD"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> onClose())
                .bounds(width / 2 - 102, height / 2 - 10, 100, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Сбросить"), b -> {
            for (String key : KEYS) {
                Settings.set("pos." + key + ".x", "0");
                Settings.set("pos." + key + ".y", "0");
            }
        }).bounds(width / 2 + 2, height / 2 - 10, 100, 20).build());
    }

    // стандартное место блока: x, y, ширина, высота
    private int[] base(String key) {
        float s = Settings.number("inventory.size", 70) / 100f;
        return switch (key) {
            case "info" -> new int[]{5, 5, 110, 28};
            case "effects" -> new int[]{5, 40, 110, 28};
            case "armor" -> new int[]{width / 2 + 98, height - 19, 72, 16};
            case "inventory" -> new int[]{(int) (width - 168 * s - 4), (int) (height - 60 * s - 28),
                    (int) (168 * s), (int) (60 * s)};
            case "cooldowns" -> new int[]{width - 84, 40, 80, 18};
            case "hotbar" -> new int[]{width / 2 - 91, height - 22, 182, 22};
            case "health" -> new int[]{width / 2 - 91, height - 49, 81, 19};
            case "food" -> new int[]{width / 2 + 10, height - 39, 81, 10};
            case "xp" -> new int[]{width / 2 - 91, height - 29, 182, 7};
            case "icons" -> new int[]{width - 52, 1, 50, 26};
            case "boss" -> new int[]{width / 2 - 91, 3, 182, 16};
            case "score" -> new int[]{width - 90, height / 2 - 10, 88, 60};
            case "chat" -> new int[]{2, height - 120, 160, 70};
            default -> new int[]{width - 84, 62, 80, 18};
        };
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, width, height, 0x6004101B);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        boolean down = GLFW.glfwGetMouseButton(minecraft.getWindow().handle(),
                GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (!down) dragged = null;

        for (int i = 0; i < KEYS.length; i++) {
            String key = KEYS[i];
            int[] b = base(key);
            int x = b[0] + Settings.number("pos." + key + ".x", 0);
            int y = b[1] + Settings.number("pos." + key + ".y", 0);
            if (down && !wasDown && dragged == null
                    && mouseX >= x && mouseX < x + b[2] && mouseY >= y && mouseY < y + b[3]) {
                dragged = key;
                grabX = mouseX - x;
                grabY = mouseY - y;
            }
            if (key.equals(dragged)) {
                x = Math.max(0, Math.min(width - b[2], mouseX - grabX));
                y = Math.max(0, Math.min(height - b[3], mouseY - grabY));
                if (x - b[0] != Settings.number("pos." + key + ".x", 0)) {
                    Settings.set("pos." + key + ".x", String.valueOf(x - b[0]));
                }
                if (y - b[1] != Settings.number("pos." + key + ".y", 0)) {
                    Settings.set("pos." + key + ".y", String.valueOf(y - b[1]));
                }
            }
            Neon.glow(g, x, y, b[2], b[3], 0xA8E6FF);
            g.fill(x, y, x + b[2], y + b[3], 0x80122638);
            g.drawString(font, Fonts.medium(NAMES[i]), x + 3, y + 3, 0xFFF2FBFF, true);
        }
        wasDown = down;
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }
}
