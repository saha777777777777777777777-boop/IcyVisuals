package ru.icevisuals;

import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.DustParticleOptions;

// Линия-след за своим персонажем
final class Trail {
    private static double lastX, lastY, lastZ;

    static void tick(Minecraft mc) {
        var player = mc.player;
        if (player == null || mc.level == null || mc.isPaused()) return;
        double x = player.getX(), y = player.getY() + 0.1, z = player.getZ();
        double dx = x - lastX, dy = y - lastY, dz = z - lastZ;
        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        // стоим на месте, телепортировались или невидимы: линию не рисуем
        if (Settings.on("trail") && !player.isInvisible() && distance > 0.02 && distance < 4) {
            var dust = new DustParticleOptions(Settings.color("trail.color") & 0xFFFFFF, 0.6f);
            int steps = (int) Math.ceil(distance / 0.07);
            for (int i = 0; i < steps; i++) {
                double t = (double) i / steps;
                mc.level.addParticle(dust, lastX + dx * t, lastY + dy * t, lastZ + dz * t, 0, 0, 0);
            }
        }
        lastX = x;
        lastY = y;
        lastZ = z;
    }
}
