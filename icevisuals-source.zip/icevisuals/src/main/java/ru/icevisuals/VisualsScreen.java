package ru.icevisuals;

import net.minecraft.client.OptionInstance;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class VisualsScreen extends Screen {
    private static final String[] TABS = {"HUD", "Визуалы", "Метки", "Чат"};
    private static int tab = 0;
    private int page = 0;
    private String opened;
    private String openedTitle;
    private String helpText = "";

    // кнопка, которую рисуем сами
    private record Item(Button button, Supplier<String> text, Supplier<Integer> swatch, Supplier<Boolean> active) {}
    private record Label(String text, int x, int y) {}

    private final List<Item> items = new ArrayList<>();
    private final List<Label> labels = new ArrayList<>();
    private int left, top;

    private final Screen parent;

    public VisualsScreen(Screen parent) {
        super(Component.literal("Визуалы"));
        this.parent = parent;
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    @Override
    protected void init() {
        items.clear();
        labels.clear();
        values.clear();
        helpText = "";
        left = width / 2 - 160;
        top = height / 2 - 105;
        for (int i = 0; i < TABS.length; i++) {
            int index = i;
            item(left + 8, top + 30 + i * 22, 70, 19, () -> TABS[index], null, () -> tab == index,
                    () -> { tab = index; opened = null; page = 0; rebuildWidgets(); });
        }
        item(left + 8, top + 186, 70, 17, () -> "Закрыть", null, () -> false, this::onClose);
        int y = top + 30;
        if (opened != null) {
            // страница настроек одной функции
            item(left + 262, top + 6, 50, 17, () -> "‹ Назад", null, () -> false,
                    () -> { opened = null; rebuildWidgets(); });
            settings(opened, y);
            return;
        }
        switch (tab) {
            case 0 -> {
                feature("Info Panel", "info", y);
                feature("Potion Timer", "effects", y + 22);
                feature("Armor HUD", "armor", y + 44);
                feature("Health Tags", "tags", y + 66);
                feature("Inventory View", "inventory", y + 88);
                feature("Cooldowns", "cooldowns", y + 110);
                feature("Trap Timer", "timers", y + 132);
            }
            case 1 -> {
                feature("Crosshair", "crosshair", y);
                feature("Hit Particles", "particles", y + 22);
                feature("Box Preview", "preview", y + 44);
                feature("Block Glow", "blockglow", y + 66);
            }
            case 2 -> feature("Waypoints", "points", y);
            default -> feature("Chat Style", "chat", y);
        }
    }

    // строка функции: название, настройки, вкл/выкл
    private void feature(String title, String key, int y) {
        labels.add(new Label(title, left + 86, y + 6));
        item(left + 181, y, 18, 19, () -> "?", null, () -> false,
                () -> { opened = "?" + key; openedTitle = title; rebuildWidgets(); });
        item(left + 202, y, 60, 19, () -> "Настройки", null, () -> false,
                () -> { opened = key; openedTitle = title; page = 0; rebuildWidgets(); });
        if (key.equals("chat")) return; // чат включается в настройках игры
        item(left + 266, y, 46, 19, () -> Settings.on(key) ? "Вкл" : "Выкл", null, () -> Settings.on(key),
                () -> Settings.toggle(key));
    }

    private static String help(String key) {
        return switch (key) {
            case "info" -> "Показывает FPS и ваши координаты.";
            case "effects" -> "Список активных эффектов и сколько им осталось.";
            case "armor" -> "Ваша броня и её прочность рядом с хотбаром.";
            case "tags" -> "Ник и сердечки над игроками и мобами. За стеной и на присевших не видно. Невидимые включаются отдельно.";
            case "inventory" -> "Содержимое инвентаря прямо на экране.";
            case "cooldowns" -> "Сколько ждать, пока предмет снова можно использовать.";
            case "timers" -> "Отсчёт после трапки или пласта. Время задаёте сами в настройках.";
            case "crosshair" -> "Свой прицел: размер, отступ, толщина, цвет.";
            case "particles" -> "Цветные частицы при ударе по цели.";
            case "preview" -> "Наведите курсор на шалкер или мешок, чтобы увидеть содержимое.";
            case "points" -> "Метки на местах, видны сквозь стены и издалека. B: поставить метку.";
            case "chat" -> "Размер, ширина и прозрачность чата.";
            case "blockglow" -> "Неоновая рамка вокруг блока, на который вы смотрите.";
            default -> "";
        };
    }

    private void settings(String key, int y) {
        if (key.startsWith("?")) {
            helpText = help(key.substring(1));
            return;
        }
        switch (key) {
            case "info", "effects" -> {
                size(key + ".size", y);
                color("Цвет", key + ".color", y + 22);
            }
            case "armor" -> size("armor.size", y);
            case "tags" -> {
                size("tags.size", y);
                stepper("Дальность", "tags.range", 24, 8, 32, 4, " м", y + 22);
                color("Цвет ника", "tags.color", y + 44);
                labels.add(new Label("Невидимые (только Лайт)", left + 86, y + 72));
                item(left + 262, y + 66, 50, 19, () -> Settings.enabled("tags.invisible") ? "Вкл" : "Выкл", null,
                        () -> Settings.enabled("tags.invisible"),
                        () -> Settings.set("tags.invisible", String.valueOf(!Settings.enabled("tags.invisible"))));
            }
            case "crosshair" -> {
                stepper("Длина линий", "cross.length", 4, 1, 15, 1, "", y);
                stepper("Отступ", "cross.gap", 2, 0, 10, 1, "", y + 22);
                stepper("Толщина", "cross.width", 1, 1, 5, 1, "", y + 44);
                color("Цвет", "cross.color", y + 66);
            }
            case "particles" -> {
                stepper("Количество", "part.count", 18, 2, 80, 4, "", y);
                stepper("Размер", "part.size", 100, 25, 400, 25, "%", y + 22);
                color("Цвет", "part.color", y + 44);
            }
            case "inventory" -> stepper("Размер", "inventory.size", 70, 40, 150, 10, "%", y);
            case "cooldowns" -> size("cooldowns.size", y);
            case "timers" -> {
                size("timers.size", y);
                stepper("Трапка", "timers.trap", 15, 1, 120, 1, " с", y + 22);
                stepper("Пласт", "timers.layer", 20, 1, 120, 1, " с", y + 44);
            }
            case "blockglow" -> color("Цвет", "blockglow.color", y);
            case "preview" -> size("preview.size", y);
            case "points" -> initPoints(y);
            default -> {
                chat("Размер текста", minecraft.options.chatScale(), y);
                chat("Ширина чата", minecraft.options.chatWidth(), y + 22);
                chat("Видимость текста", minecraft.options.chatOpacity(), y + 44);
                chat("Фон чата", minecraft.options.textBackgroundOpacity(), y + 66);
            }
        }
    }

    private void size(String key, int y) {
        stepper("Размер", key, 100, 50, 200, 10, "%", y);
    }

    private void initPoints(int y) {
        stepper("Размер меток", "points.size", 100, 50, 200, 10, "%", y);
        color("Цвет новой метки", "points.color", y + 22);

        if (minecraft.player == null) {
            labels.add(new Label("Список меток доступен в игре", left + 86, y + 52));
            return;
        }
        int x = left + 86;
        EditBox name = field(x, y + 66, 78, "Название", "");
        var player = minecraft.player;
        EditBox px = field(x + 82, y + 66, 46, "X", String.valueOf(player.getBlockX()));
        EditBox py = field(x + 130, y + 66, 34, "Y", String.valueOf(player.getBlockY()));
        EditBox pz = field(x + 166, y + 66, 46, "Z", String.valueOf(player.getBlockZ()));
        item(x + 214, y + 66, 12, 18, () -> "+", null, () -> true, () -> {
            try {
                Waypoints.add(name.getValue(), Integer.parseInt(px.getValue().trim()),
                        Integer.parseInt(py.getValue().trim()), Integer.parseInt(pz.getValue().trim()));
                rebuildWidgets();
            } catch (NumberFormatException ignored) {
                // в координатах не число: ничего не добавляем
            }
        });

        List<Waypoints.Point> points = Waypoints.list();
        int pages = Math.max(1, (points.size() + 2) / 3);
        page = Math.min(page, pages - 1);
        for (int row = 0; row < 3 && page * 3 + row < points.size(); row++) {
            int index = page * 3 + row;
            Waypoints.Point p = points.get(index);
            int ry = y + 90 + row * 20;
            labels.add(new Label(p.name() + "  (" + p.x() + " " + p.y() + " " + p.z() + ")", x, ry + 5));
            item(x + 208, ry, 18, 17, () -> "×", null, () -> false,
                    () -> { Waypoints.remove(index); rebuildWidgets(); });
        }
        if (pages > 1) {
            item(x, y + 152, 226, 17, () -> "Страница " + (page + 1) + "/" + pages + "  ›", null, () -> false,
                    () -> { page = (page + 1) % pages; rebuildWidgets(); });
        }
    }

    private EditBox field(int x, int y, int w, String hint, String value) {
        EditBox box = new EditBox(font, x, y, w, 18, Component.literal(hint));
        box.setMaxLength(24);
        box.setValue(value);
        box.setHint(Component.literal(hint));
        return addRenderableWidget(box);
    }

    private void stepper(String title, String key, int fallback, int min, int max, int step, String unit, int y) {
        labels.add(new Label(title, left + 86, y + 6));
        item(left + 232, y, 19, 19, () -> "−", null, () -> false,
                () -> Settings.set(key, String.valueOf(Math.max(min, Settings.number(key, fallback) - step))));
        item(left + 293, y, 19, 19, () -> "+", null, () -> false,
                () -> Settings.set(key, String.valueOf(Math.min(max, Settings.number(key, fallback) + step))));
        values.add(new Value(() -> Settings.number(key, fallback) + unit, left + 272, y + 6));
    }

    private void chat(String title, OptionInstance<Double> option, int y) {
        labels.add(new Label(title, left + 86, y + 6));
        item(left + 232, y, 19, 19, () -> "−", null, () -> false, () -> change(option, -0.1));
        item(left + 293, y, 19, 19, () -> "+", null, () -> false, () -> change(option, 0.1));
        values.add(new Value(() -> Math.round(option.get() * 100) + "%", left + 272, y + 6));
    }

    private void change(OptionInstance<Double> option, double step) {
        option.set(Math.max(0.0, Math.min(1.0, Math.round((option.get() + step) * 10) / 10.0)));
        minecraft.options.save();
    }

    private void color(String title, String key, int y) {
        labels.add(new Label(title, left + 86, y + 6));
        item(left + 262, y, 50, 19, () -> "", () -> Settings.color(key), () -> false, () -> Settings.nextColor(key));
    }

    private record Value(Supplier<String> text, int x, int y) {}
    private final List<Value> values = new ArrayList<>();

    private void item(int x, int y, int w, int h, Supplier<String> text, Supplier<Integer> swatch,
                      Supplier<Boolean> active, Runnable action) {
        Button button = addWidget(Button.builder(Component.literal(text.get()), b -> action.run())
                .bounds(x, y, w, h).build());
        items.add(new Item(button, text, swatch, active));
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, width, height, minecraft.level == null ? 0xFF04101B : 0x80050509);
        box(g, left, top, 320, 210, 0xF00C1A28);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        g.drawString(font, Fonts.bold("ICE VISUALS"), left + 10, top + 10, 0xFFA8E6FF, false);
        g.drawString(font, Fonts.bold(opened == null ? TABS[tab] : openedTitle), left + 86, top + 10, 0xFFF2FBFF, false);

        for (Item item : items) {
            Button b = item.button();
            boolean over = b.isMouseOver(mouseX, mouseY);
            int x = b.getX(), y = b.getY(), w = b.getWidth(), h = b.getHeight();
            box(g, x, y, w, h, item.active().get() ? 0xFF3A9CC8 : over ? 0xFF1F4A68 : 0xFF142A3E);
            if (item.swatch() != null) box(g, x + 4, y + 4, w - 8, h - 8, item.swatch().get());
            var text = Fonts.medium(item.text().get());
            g.drawString(font, text, x + (w - font.width(text)) / 2, y + (h - 8) / 2, 0xFFF2FBFF, false);
        }
        int line = top + 36;
        for (var part : font.split(Fonts.medium(helpText), 222)) {
            g.drawString(font, part, left + 86, line, 0xFFCBE6F2, false);
            line += 12;
        }
        for (Label l : labels) g.drawString(font, Fonts.medium(l.text()), l.x(), l.y(), 0xFFCBE6F2, false);
        for (Value v : values) {
            var text = Fonts.medium(v.text().get());
            g.drawString(font, text, v.x() - font.width(text) / 2, v.y(), 0xFFFFFFFF, false);
        }
    }

    private static void box(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x + 2, y, x + w - 2, y + 1, color);
        g.fill(x + 1, y + 1, x + w - 1, y + 2, color);
        g.fill(x, y + 2, x + w, y + h - 2, color);
        g.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, color);
        g.fill(x + 2, y + h - 1, x + w - 2, y + h, color);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
