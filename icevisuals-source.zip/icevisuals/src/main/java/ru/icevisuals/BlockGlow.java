package ru.icevisuals;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

// Неоновые рёбра блока, на который наведён прицел
final class BlockGlow {
    static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !Settings.on("blockglow")
                || !mc.options.getCameraType().isFirstPerson()
                || !(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;

        BlockPos pos = hit.getBlockPos();
        VoxelShape shape = mc.level.getBlockState(pos).getShape(mc.level, pos);
        if (shape.isEmpty()) return;
        AABB box = shape.bounds().move(pos);

        float partial = delta.getGameTimeDeltaPartialTick(true);
        Vec3 eye = mc.player.getEyePosition(partial);
        double yaw = Math.toRadians(mc.player.getViewYRot(partial));
        double pitch = Math.toRadians(mc.player.getViewXRot(partial));
        double sy = Math.sin(yaw), cy = Math.cos(yaw), sp = Math.sin(pitch), cp = Math.cos(pitch);
        double focal = (g.guiHeight() / 2.0) / Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);

        // 8 углов в координатах камеры: вправо, вверх, вглубь
        double[][] c = new double[8][];
        for (int i = 0; i < 8; i++) {
            double dx = ((i & 1) == 0 ? box.minX : box.maxX) - eye.x;
            double dy = ((i & 2) == 0 ? box.minY : box.maxY) - eye.y;
            double dz = ((i & 4) == 0 ? box.minZ : box.maxZ) - eye.z;
            c[i] = new double[]{
                    -dx * cy - dz * sy,
                    -dx * sy * sp + dy * cp + dz * cy * sp,
                    -dx * sy * cp - dy * sp + dz * cy * cp};
        }

        int rgb = Settings.color("blockglow.color") & 0xFFFFFF;
        for (int i = 0; i < 8; i++) {
            for (int bit = 1; bit <= 4; bit <<= 1) {
                if ((i & bit) == 0) edge(g, c[i], c[i | bit], focal, rgb);
            }
        }
    }

    private static void edge(GuiGraphics g, double[] a, double[] b, double focal, int rgb) {
        double near = 0.1;
        if (a[2] < near && b[2] < near) return;
        // обрезаем часть ребра, оказавшуюся за камерой
        if (a[2] < near || b[2] < near) {
            double t = (near - a[2]) / (b[2] - a[2]);
            double[] cut = {a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, near};
            if (a[2] < near) a = cut;
            else b = cut;
        }
        double x1 = g.guiWidth() / 2.0 + a[0] / a[2] * focal, y1 = g.guiHeight() / 2.0 - a[1] / a[2] * focal;
        double x2 = g.guiWidth() / 2.0 + b[0] / b[2] * focal, y2 = g.guiHeight() / 2.0 - b[1] / b[2] * focal;
        double length = Math.hypot(x2 - x1, y2 - y1);
        if (length < 0.5 || length > 5000) return;

        g.pose().pushMatrix();
        g.pose().translate((float) x1, (float) y1);
        g.pose().rotate((float) Math.atan2(y2 - y1, x2 - x1));
        g.pose().scale(0.5f, 0.5f);
        int end = (int) Math.round(length * 2);
        g.fill(0, -5, end, 5, 0x18000000 | rgb);
        g.fill(0, -3, end, 3, 0x40000000 | rgb);
        g.fill(0, -1, end, 1, 0xFF000000 | rgb);
        g.pose().popMatrix();
    }
}
