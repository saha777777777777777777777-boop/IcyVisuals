package ru.icevisuals.mixin;

import net.minecraft.world.attribute.EnvironmentAttribute;
import net.minecraft.world.attribute.EnvironmentAttributeProbe;
import net.minecraft.world.attribute.EnvironmentAttributes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.icevisuals.SkyColors;

// Подменяет цвет неба, тумана и яркость звёзд (только на экране игрока)
@Mixin(EnvironmentAttributeProbe.class)
public class SkyMixin {
    @Inject(method = "getValue", at = @At("RETURN"), cancellable = true, require = 0)
    private void icevisuals$sky(EnvironmentAttribute<?> attribute, float partialTick,
                                CallbackInfoReturnable<Object> info) {
        if (attribute == EnvironmentAttributes.SKY_COLOR) {
            if (SkyColors.on("sky")) info.setReturnValue(SkyColors.sky());
        } else if (attribute == EnvironmentAttributes.FOG_COLOR) {
            if (SkyColors.on("fog")) info.setReturnValue(SkyColors.fog());
        } else if (attribute == EnvironmentAttributes.STAR_BRIGHTNESS) {
            if (SkyColors.on("stars")) info.setReturnValue(SkyColors.stars());
        }
    }
}
