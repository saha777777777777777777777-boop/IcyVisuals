package ru.icevisuals;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

public class IceVisuals implements ClientModInitializer {
    private boolean shiftWasDown;
    private boolean markWasDown;
    private boolean wasDead;

    // Цвета темы: меняйте здесь
    private static final int PANEL = 0x900E1C2A;

    @Override
    public void onInitializeClient() {
        ContainerPreview.register();
        ClientTickEvents.END_CLIENT_TICK.register(Trail::tick);
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("icevisuals", "blockglow"), BlockGlow::render);
        ExtraHud.register();
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("icevisuals", "extra"), ExtraHud::render);

        // Вместо стандартного главного меню открываем своё
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.screen instanceof TitleScreen) mc.setScreen(new IceMenuScreen());
            if (mc.screen instanceof PauseScreen pause && pause.showsPauseMenu()) mc.setScreen(new IcePauseScreen());

            // Правый Shift открывает меню визуалов
            boolean down = InputConstants.isKeyDown(mc.getWindow(), GLFW.GLFW_KEY_RIGHT_SHIFT);
            if (down && !shiftWasDown && mc.screen == null && mc.player != null) {
                mc.setScreen(new VisualsScreen(null));
            }
            shiftWasDown = down;

            // B: поставить метку там, где стоите
            boolean mark = InputConstants.isKeyDown(mc.getWindow(), GLFW.GLFW_KEY_B);
            if (mark && !markWasDown && mc.screen == null && mc.player != null) {
                Waypoints.add("", mc.player.getBlockX(), mc.player.getBlockY(), mc.player.getBlockZ());
            }
            markWasDown = mark;

            // метка на месте смерти
            boolean dead = mc.player != null && mc.player.isDeadOrDying();
            if (dead && !wasDead && Settings.on("points")) {
                Waypoints.add("Смерть", mc.player.getBlockX(), mc.player.getBlockY(), mc.player.getBlockZ());
            }
            wasDead = dead;
        });

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("icevisuals", "hud"), IceVisuals::renderHud);

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("icevisuals", "points"), Waypoints::render);

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("icevisuals", "tags"), HealthTags::render);

        Layout.registerVanilla();

        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR,
                original -> (graphics, delta) -> {
                    if (Settings.on("crosshair")) renderCrosshair(graphics);
                    else original.render(graphics, delta);
                });

        // Частицы при ударе (видны только вам)
        AttackEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
            Minecraft mc = Minecraft.getInstance();
            if (Settings.on("particles") && (!entity.isInvisible() || Settings.enabled("tags.invisible")) && level.isClientSide() && mc.level != null && player == mc.player) {
                var dust = new DustParticleOptions(Settings.color("part.color") & 0xFFFFFF,
                        Settings.number("part.size", 100) / 100f);
                var random = player.getRandom();
                for (int i = 0; i < Settings.number("part.count", 18); i++) {
                    mc.level.addParticle(dust,
                            entity.getX() + (random.nextDouble() - 0.5) * entity.getBbWidth() * 1.5,
                            entity.getY() + random.nextDouble() * entity.getBbHeight(),
                            entity.getZ() + (random.nextDouble() - 0.5) * entity.getBbWidth() * 1.5,
                            0, 0, 0);
                }
            }
            return InteractionResult.PASS;
        });
    }

    private static void renderCrosshair(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (!mc.options.getCameraType().isFirstPerson()) return;
        int x = g.guiWidth() / 2;
        int y = g.guiHeight() / 2;
        int length = Settings.number("cross.length", 4);
        int gap = Settings.number("cross.gap", 2);
        int w = Settings.number("cross.width", 1);
        int color = Settings.color("cross.color");
        int x0 = x - w / 2, y0 = y - w / 2;
        g.fill(x0 - gap - length, y0, x0 - gap, y0 + w, color);
        g.fill(x0 + w + gap, y0, x0 + w + gap + length, y0 + w, color);
        g.fill(x0, y0 - gap - length, x0 + w, y0 - gap, color);
        g.fill(x0, y0 + w + gap, x0 + w, y0 + w + gap + length, color);
    }

    private static void renderHud(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        var player = mc.player;
        if (player == null || mc.getDebugOverlay().showDebugScreen()) return;

        Layout.push(g, "info");
        float scale = Settings.number("info.size", 100) / 100f;
        g.pose().pushMatrix();
        g.pose().scale(scale, scale);
        if (Settings.on("info")) {
            panel(g, mc, "Ice Visuals | FPS " + mc.getFps(), 5, 5, Settings.color("info.color"));
            panel(g, mc, "XYZ " + player.getBlockX() + " " + player.getBlockY() + " " + player.getBlockZ(), 5, 20, Settings.color("info.color"));
        }

        // Эффекты с таймером
        g.pose().popMatrix();
        Layout.pop(g);

        // у эффектов свой масштаб; начинаются ниже блока FPS
        Layout.push(g, "effects");
        float effectScale = Settings.number("effects.size", 100) / 100f;
        g.pose().pushMatrix();
        g.pose().translate(0, Settings.on("info") ? 35 * scale : 5);
        g.pose().scale(effectScale, effectScale);
        int y = 0;
        for (MobEffectInstance effect : player.getActiveEffects()) {
            if (!Settings.on("effects")) break;
            String time = "∞";
            if (!effect.isInfiniteDuration()) {
                int s = effect.getDuration() / 20;
                time = String.format("%d:%02d", s / 60, s % 60);
            }
            String name = effect.getEffect().value().getDisplayName().getString();
            panel(g, mc, name + " " + (effect.getAmplifier() + 1) + "  " + time, 5, y, Settings.color("effects.color"));
            y += 15;
        }

        g.pose().popMatrix();

        Layout.pop(g);

        // Броня справа от хотбара
        Layout.push(g, "armor");
        float armorScale = Settings.number("armor.size", 100) / 100f;
        g.pose().pushMatrix();
        g.pose().translate(g.guiWidth() / 2f + 98, g.guiHeight() - 3 - 16 * armorScale);
        g.pose().scale(armorScale, armorScale);
        int x = 0;
        int armorY = 0;
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST,
                EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack stack = player.getItemBySlot(slot);
            if (stack.isEmpty() || !Settings.on("armor")) continue;
            g.renderItem(stack, x, armorY);
            g.renderItemDecorations(mc.font, stack, x, armorY);
            x += 18;
        }
        g.pose().popMatrix();
        Layout.pop(g);
    }

    private static void panel(GuiGraphics g, Minecraft mc, String text, int x, int y, int color) {
        int width = mc.font.width(Fonts.medium(text)) + 10;
        Neon.glow(g, x, y, width, 13, color);
        g.fill(x, y, x + width, y + 13, PANEL);
        g.fill(x, y, x + 2, y + 13, color);
        g.drawString(mc.font, Fonts.medium(text), x + 6, y + 3, color, true);
    }
}
