package ru.icevisuals;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

final class Settings {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("icevisuals.properties");
    private static final Properties VALUES = new Properties();
    static final int[] COLORS = {0xA8E6FF, 0xFFFFFF, 0xFF6B81, 0xFFB86B, 0xFFE66D, 0x7CF29C, 0x6EE7F9, 0x7AA2FF, 0xF59AD8};

    static {
        if (Files.exists(FILE)) {
            try (Reader reader = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
                VALUES.load(reader);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    static String get(String key, String fallback) {
        return VALUES.getProperty(key, fallback);
    }

    static void set(String key, String value) {
        VALUES.setProperty(key, value);
        try (Writer writer = Files.newBufferedWriter(FILE, StandardCharsets.UTF_8)) {
            VALUES.store(writer, "Ice Visuals");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static boolean on(String key) {
        return !"false".equals(get(key, "true"));
    }

    // для настроек, выключенных по умолчанию
    static boolean enabled(String key) {
        return "true".equals(get(key, "false"));
    }

    static void toggle(String key) {
        set(key, String.valueOf(!on(key)));
    }

    static int number(String key, int fallback) {
        try {
            return Integer.parseInt(get(key, String.valueOf(fallback)));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    // цвет в формате ARGB, непрозрачный
    static int color(String key) {
        return 0xFF000000 | COLORS[Math.floorMod(number(key, 0), COLORS.length)];
    }

    static void nextColor(String key) {
        set(key, String.valueOf(Math.floorMod(number(key, 0) + 1, COLORS.length)));
    }
}
