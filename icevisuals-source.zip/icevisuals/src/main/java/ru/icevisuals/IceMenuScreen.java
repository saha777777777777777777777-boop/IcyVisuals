package ru.icevisuals;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class IceMenuScreen extends Screen {
    private final List<Entry> entries = new ArrayList<>();
    private final List<Star> stars = new ArrayList<>();
    private final Random random = new Random();
    private final long opened = System.nanoTime();
    private long lastFrame = System.nanoTime();
    private float time;

    private static class Star {
        float homeX, homeY, offX, offY, phase, drift;
        int size;
    }

    private static class Entry {
        Button button;
        String title, subtitle;
        float hover;
    }

    public IceMenuScreen() {
        super(Component.literal("Ice Visuals"));
    }

    @Override
    protected void init() {
        entries.clear();
        stars.clear();
        for (int i = 0; i < 260; i++) {
            Star s = new Star();
            s.homeX = random.nextFloat() * width;
            s.homeY = random.nextFloat() * height;
            s.phase = random.nextFloat() * 6.28f;
            s.drift = 1f + random.nextFloat() * 3f;
            s.size = random.nextInt(12) == 0 ? 3 : random.nextInt(3) == 0 ? 2 : 1;
            stars.add(s);
        }
        int x = width / 2 - 110;
        int y = height / 2 - 32;
        add("Одиночная игра", "Ваши миры", x, y, 220, 30,
                () -> minecraft.setScreen(new SelectWorldScreen(this)));
        add("Сетевая игра", "Серверы и друзья", x, y + 36, 220, 30,
                () -> minecraft.setScreen(new JoinMultiplayerScreen(this)));
        add("Настройки", null, x, y + 72, 107, 24,
                () -> minecraft.setScreen(new OptionsScreen(this, minecraft.options)));
        add("Выход", null, x + 113, y + 72, 107, 24, () -> minecraft.stop());
        add("Ice Visuals", null, x, y + 102, 220, 22, () -> minecraft.setScreen(new VisualsScreen(this)));
    }

    private void add(String title, String subtitle, int x, int y, int w, int h, Runnable action) {
        Entry e = new Entry();
        e.title = title;
        e.subtitle = subtitle;
        // addWidget: кнопка ловит клики, но рисуем мы её сами
        e.button = addWidget(Button.builder(Component.literal(title), b -> action.run())
                .bounds(x, y, w, h).build());
        entries.add(e);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        // фон рисуется в render
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        long now = System.nanoTime();
        float dt = Math.min((now - lastFrame) / 1_000_000_000f, 0.05f);
        lastFrame = now;
        time += dt;
        float intro = Math.min((now - opened) / 600_000_000f, 1f);
        intro = 1f - (1f - intro) * (1f - intro) * (1f - intro);

        g.fillGradient(0, 0, width, height, 0xFF04101B, 0xFF0C2A42);
        glow(g, width * 0.18f + (float) Math.sin(time * 0.3f) * 20, height * 0.8f, 120, 0x2F9FE0);
        glow(g, width * 0.85f, height * 0.2f + (float) Math.cos(time * 0.25f) * 15, 100, 0x4FD0D8);
        drawStars(g, mouseX, mouseY, dt);
        drawShootingStar(g);

        // Заголовок с переливом
        float titleY = height / 2f - 86 - (1f - intro) * 12;
        gradientTitle(g, "ICE VISUALS", width / 2f, titleY, 2.8f);
        centered(g, Fonts.medium("MINECRAFT 1.21.11"), width / 2f, titleY + 32, 0xFF86AFC6);

        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            boolean over = e.button.isMouseOver(mouseX, mouseY) || e.button.isFocused();
            e.hover += ((over ? 1f : 0f) - e.hover) * (1f - (float) Math.exp(-14f * dt));
            drawButton(g, e, (1f - intro) * (20 + i * 10));
        }
    }

    private void drawButton(GuiGraphics g, Entry e, float slide) {
        Button b = e.button;
        int w = b.getWidth(), h = b.getHeight();
        g.pose().pushMatrix();
        g.pose().translate(b.getX(), b.getY() + slide - e.hover * 1.5f);

        // двойное разрешение, чтобы углы были гладкими
        g.pose().pushMatrix();
        g.pose().scale(0.5f, 0.5f);
        for (int i = 3; i >= 1; i--) {
            roundRect(g, -i * 2, -i * 2, w * 2 + i * 4, h * 2 + i * 4, 14 + i * 2,
                    color((int) (22 * e.hover), 0x6FD3FF));
        }
        roundRect(g, 0, 0, w * 2, h * 2, 14, mix(0x408FD0EE, 0xE0A8E6FF, e.hover));
        roundRect(g, 2, 2, w * 2 - 4, h * 2 - 4, 12, mix(0xE00C1A28, 0xF01D4663, e.hover));
        g.pose().popMatrix();

        if (e.subtitle != null) {
            int shift = (int) (e.hover * 4);
            g.drawString(font, Fonts.bold(e.title), 14 + shift, 5, 0xFFF4FCFF, false);
            g.drawString(font, Fonts.medium(e.subtitle), 14 + shift, 18, 0xFF86AFC6, false);
            g.drawString(font, Fonts.bold("›"), w - 18 + shift, 10,
                    mix(0xFF5C8BA6, 0xFFDFF6FF, e.hover), false);
        } else {
            centered(g, Fonts.bold(e.title), w / 2f, 7, mix(0xFFC5E2F0, 0xFFFFFFFF, e.hover));
        }
        g.pose().popMatrix();
    }

    private void drawStars(GuiGraphics g, int mouseX, int mouseY, float dt) {
        float radius = 60f, push = 34f;
        float ease = 1f - (float) Math.exp(-8f * dt);
        for (Star s : stars) {
            s.homeX += s.drift * dt;
            if (s.homeX > width) s.homeX -= width;
            float dx = s.homeX - mouseX, dy = s.homeY - mouseY;
            float d = (float) Math.sqrt(dx * dx + dy * dy);
            float tx = 0, ty = 0;
            if (d < radius && d > 0.01f) {
                float force = (1f - d / radius) * push;
                tx = dx / d * force;
                ty = dy / d * force;
            }
            s.offX += (tx - s.offX) * ease;
            s.offY += (ty - s.offY) * ease;
            s.phase += dt * 2f;
            int alpha = 150 + (int) (Math.sin(s.phase) * 100);

            g.pose().pushMatrix();
            g.pose().translate(s.homeX + s.offX, s.homeY + s.offY);
            g.pose().scale(0.5f, 0.5f);
            g.fill(0, 0, s.size, s.size, color(alpha, 0xE4F7FF));
            if (s.size == 3) { // крупные звёзды с лучами
                g.fill(1, -3, 2, 6, color(alpha / 2, 0xA8E6FF));
                g.fill(-3, 1, 6, 2, color(alpha / 2, 0xA8E6FF));
            }
            g.pose().popMatrix();
        }
    }

    // Падающая звезда раз в 4 секунды
    private void drawShootingStar(GuiGraphics g) {
        float t = time % 4f;
        if (t > 0.9f) return;
        int n = (int) (time / 4f);
        float x = width * (0.15f + (n * 37 % 60) / 100f) + t * 180;
        float y = height * (0.05f + (n * 53 % 30) / 100f) + t * 80;
        float fade = (float) Math.sin(t / 0.9f * Math.PI);
        for (int i = 0; i < 24; i++) {
            int px = (int) (x - i * 1.8f), py = (int) (y - i * 0.8f);
            g.fill(px, py, px + 2, py + 1, color((int) (230 * fade * (1f - i / 24f)), 0xDFF6FF));
        }
    }

    private void glow(GuiGraphics g, float cx, float cy, int radius, int rgb) {
        for (int i = 10; i >= 1; i--) {
            int r = radius * i / 10;
            roundRect(g, (int) cx - r, (int) cy - r, r * 2, r * 2, r, color(5, rgb));
        }
    }

    private void gradientTitle(GuiGraphics g, String text, float cx, float y, float scale) {
        int total = font.width(Fonts.bold(text));
        g.pose().pushMatrix();
        g.pose().translate(cx - total * scale / 2f, y);
        g.pose().scale(scale, scale);
        int x = 0;
        for (int i = 0; i < text.length(); i++) {
            var letter = Fonts.bold(text.substring(i, i + 1));
            float k = (float) (Math.sin(time * 2f - i * 0.45f) + 1) / 2f;
            g.drawString(font, letter, x, 0, mix(0xFF6FD3FF, 0xFFF0FCFF, k), false);
            x += font.width(letter);
        }
        g.pose().popMatrix();
    }

    private void centered(GuiGraphics g, Component text, float cx, float y, int color) {
        g.drawString(font, text, (int) (cx - font.width(text) / 2f), (int) y, color, false);
    }

    private static void roundRect(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        if ((color >>> 24) == 0) return;
        for (int row = 0; row < r; row++) {
            double dy = r - row - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            g.fill(x + inset, y + row, x + w - inset, y + row + 1, color);
            g.fill(x + inset, y + h - row - 1, x + w - inset, y + h - row, color);
        }
        if (h > r * 2) g.fill(x, y + r, x + w, y + h - r, color);
    }

    private static int color(int alpha, int rgb) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | rgb;
    }

    private static int mix(int a, int b, float k) {
        int result = 0;
        for (int shift = 0; shift < 32; shift += 8) {
            int from = (a >>> shift) & 255, to = (b >>> shift) & 255;
            result |= ((int) (from + (to - from) * Math.max(0f, Math.min(1f, k))) & 255) << shift;
        }
        return result;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
