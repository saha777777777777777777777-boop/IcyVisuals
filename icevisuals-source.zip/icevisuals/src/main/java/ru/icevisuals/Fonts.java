package ru.icevisuals;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;

final class Fonts {
    private static final Style MEDIUM = style("medium");
    private static final Style BOLD = style("bold");

    private static Style style(String name) {
        return Style.EMPTY.withFont(new FontDescription.Resource(
                Identifier.fromNamespaceAndPath("icevisuals", name)));
    }

    static MutableComponent medium(String text) {
        return Component.literal(text).setStyle(MEDIUM);
    }

    static MutableComponent bold(String text) {
        return Component.literal(text).setStyle(BOLD);
    }
}
