package ru.icevisuals;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

// Инвентарь на экране, кулдауны предметов и таймеры трапки/пласта
final class ExtraHud {
    private record Timer(ItemStack icon, long start, long end) {}
    // первое замеченное значение кулдауна: по скорости убывания считаем секунды
    private record Seen(float percent, long time) {}

    private static final Map<String, Timer> TIMERS = new LinkedHashMap<>();
    private static final Map<String, Seen> SEEN = new HashMap<>();

    static void register() {
        UseItemCallback.EVENT.register((player, level, hand) -> {
            if (level.isClientSide()) used(player, hand);
            return InteractionResult.PASS;
        });
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (level.isClientSide()) used(player, hand);
            return InteractionResult.PASS;
        });
    }

    // Сервер не сообщает длительность, поэтому отсчитываем время из настроек
    private static void used(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player != Minecraft.getInstance().player || stack.isEmpty()
                || player.getCooldowns().isOnCooldown(stack)) return;
        String name = stack.getHoverName().getString().toLowerCase(Locale.ROOT);
        if (name.contains("трапка")) start("Трапка", stack, Settings.number("timers.trap", 15));
        else if (name.contains("пласт")) start("Пласт", stack, Settings.number("timers.layer", 20));
    }

    private static void start(String title, ItemStack stack, int seconds) {
        long now = System.currentTimeMillis();
        Timer old = TIMERS.get(title);
        if (old != null && now - old.start() < 1000) return; // повторный вызов того же клика
        TIMERS.put(title, new Timer(stack.copy(), now, now + seconds * 1000L));
    }

    static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getDebugOverlay().showDebugScreen()) {
            return;
        }
        if (Settings.on("inventory")) {
            Layout.push(g, "inventory");
            inventory(g, mc);
            Layout.pop(g);
        }

        int y = 40;
        if (Settings.on("cooldowns")) {
            Layout.push(g, "cooldowns");
            y = cooldowns(g, mc, delta, y);
            Layout.pop(g);
        }
        if (Settings.on("timers")) {
            Layout.push(g, "timers");
            timers(g, mc, Math.max(y, 62));
            Layout.pop(g);
        }
    }

    private static void inventory(GuiGraphics g, Minecraft mc) {
        float scale = Settings.number("inventory.size", 70) / 100f;
        int w = 9 * 18 + 6, h = 3 * 18 + 6;
        g.pose().pushMatrix();
        g.pose().translate(g.guiWidth() - w * scale - 4, g.guiHeight() - h * scale - 28);
        g.pose().scale(scale, scale);
        g.fill(0, 0, w, h, 0x900E1C2A);
        g.fill(0, 0, w, 2, 0xFFA8E6FF);
        // ячейки 9..35 это основная часть инвентаря без хотбара
        for (int i = 9; i < 36; i++) {
            ItemStack item = mc.player.getInventory().getItem(i);
            if (item.isEmpty()) continue;
            int x = 4 + ((i - 9) % 9) * 18;
            int y = 4 + ((i - 9) / 9) * 18;
            g.renderItem(item, x, y);
            g.renderItemDecorations(mc.font, item, x, y);
        }
        g.pose().popMatrix();
    }

    private static int cooldowns(GuiGraphics g, Minecraft mc, DeltaTracker delta, int y) {
        float partial = delta.getGameTimeDeltaPartialTick(true);
        long now = System.currentTimeMillis();
        Map<String, ItemStack> active = new LinkedHashMap<>();
        for (int i = 0; i < mc.player.getInventory().getContainerSize(); i++) {
            ItemStack item = mc.player.getInventory().getItem(i);
            if (!item.isEmpty() && mc.player.getCooldowns().isOnCooldown(item)) {
                active.putIfAbsent(item.getItem().toString(), item);
            }
        }
        SEEN.keySet().retainAll(active.keySet());

        for (var entry : active.entrySet()) {
            float percent = mc.player.getCooldowns().getCooldownPercent(entry.getValue(), partial);
            Seen first = SEEN.get(entry.getKey());
            if (first == null || percent > first.percent()) {
                first = new Seen(percent, now);
                SEEN.put(entry.getKey(), first);
            }
            String time = Math.round(percent * 100) + "%";
            float passed = first.percent() - percent;
            if (passed > 0.01f && now - first.time() > 500) {
                double left = percent * (now - first.time()) / passed / 1000.0;
                time = (int) Math.ceil(left) + " с";
            }
            line(g, mc, entry.getValue(), "КД  " + time, y, "cooldowns.size");
            y += Math.round(20 * Settings.number("cooldowns.size", 100) / 100f);
        }
        return y;
    }

    private static void timers(GuiGraphics g, Minecraft mc, int y) {
        long now = System.currentTimeMillis();
        TIMERS.values().removeIf(t -> t.end() <= now);
        for (var entry : TIMERS.entrySet()) {
            long left = (entry.getValue().end() - now + 999) / 1000;
            line(g, mc, entry.getValue().icon(), entry.getKey() + "  " + left + " с", y, "timers.size");
            y += Math.round(20 * Settings.number("timers.size", 100) / 100f);
        }
    }

    private static void line(GuiGraphics g, Minecraft mc, ItemStack icon, String text, int y, String sizeKey) {
        float scale = Settings.number(sizeKey, 100) / 100f;
        var label = Fonts.medium(text);
        int w = mc.font.width(label) + 28;
        g.pose().pushMatrix();
        g.pose().translate(g.guiWidth() - w * scale - 4, y);
        g.pose().scale(scale, scale);
        g.fill(0, 0, w, 18, 0x900E1C2A);
        g.renderItem(icon, 2, 1);
        g.drawString(mc.font, label, 22, 5, 0xFFF2FBFF, true);
        g.pose().popMatrix();
    }
}
