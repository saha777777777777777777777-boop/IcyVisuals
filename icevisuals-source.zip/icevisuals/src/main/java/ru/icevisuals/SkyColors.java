package ru.icevisuals;

public final class SkyColors {
    public static boolean on(String key) {
        return Settings.on(key);
    }

    // яркость в процентах делает небо темнее, чтобы были видны звёзды
    private static int shade(String colorKey, String levelKey, int fallback) {
        int color = Settings.color(colorKey);
        float k = Settings.number(levelKey, fallback) / 100f;
        int r = (int) (((color >> 16) & 255) * k);
        int g = (int) (((color >> 8) & 255) * k);
        int b = (int) ((color & 255) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    public static Integer sky() {
        return shade("sky.color", "sky.level", 30);
    }

    public static Integer fog() {
        return shade("fog.color", "fog.level", 55);
    }

    public static Float stars() {
        return Settings.number("stars.level", 80) / 100f;
    }
}
