package ru.icevisuals;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;

final class HealthTags {
    // Не показывает присевших и тех, кто за стеной
    static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !Settings.on("tags")
                || !mc.options.getCameraType().isFirstPerson()) return;

        float partial = delta.getGameTimeDeltaPartialTick(true);
        Vec3 eye = mc.player.getEyePosition(partial);
        double yaw = Math.toRadians(mc.player.getViewYRot(partial));
        double pitch = Math.toRadians(mc.player.getViewXRot(partial));
        double sy = Math.sin(yaw), cy = Math.cos(yaw), sp = Math.sin(pitch), cp = Math.cos(pitch);
        double focal = (g.guiHeight() / 2.0) / Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);

        float size = Settings.number("tags.size", 100) / 100f;
        int range = Settings.number("tags.range", 24);

        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!(entity instanceof LivingEntity living) || entity instanceof ArmorStand || entity == mc.player) continue;
            if (living.isDiscrete() || !living.isAlive()) continue; // присевших не показываем
            // невидимых только по отдельной настройке (разрешено правилами Лайт-анархии)
            if (living.isInvisible() && !Settings.enabled("tags.invisible")) continue;
            if (mc.player.distanceTo(living) > range || !mc.player.hasLineOfSight(living)) continue;

            Vec3 pos = living.getPosition(partial);
            double dx = pos.x - eye.x, dy = pos.y + living.getBbHeight() + 0.8 - eye.y, dz = pos.z - eye.z;
            double depth = -dx * sy * cp - dy * sp + dz * cy * cp;
            if (depth <= 0.1) continue;
            double right = -dx * cy - dz * sy;
            double up = -dx * sy * sp + dy * cp + dz * cy * sp;
            float x = (float) (g.guiWidth() / 2.0 + right / depth * focal);
            float y = (float) (g.guiHeight() / 2.0 - up / depth * focal);

            var text = Fonts.medium(living.getName().getString());
            // сердечки: не больше 10, при большом запасе здоровья масштабируются
            float max = Math.max(1, living.getMaxHealth());
            int total = Math.max(1, Math.min(10, (int) Math.ceil(max / 2)));
            int full = Math.max(0, Math.min(total, (int) Math.ceil(living.getHealth() / max * total)));
            String red = "❤".repeat(full);
            String gray = "❤".repeat(total - full);
            int heartsWidth = mc.font.width(red + gray);
            int half = Math.max(mc.font.width(text), heartsWidth) / 2 + 4;
            g.pose().pushMatrix();
            g.pose().translate(x, y);
            g.pose().scale(size, size);
            g.fill(-half, -23, half, 0, 0xB00C1A28);
            g.drawString(mc.font, text, -mc.font.width(text) / 2, -21, Settings.color("tags.color"), true);
            g.drawString(mc.font, red, -heartsWidth / 2, -10, 0xFFFF5470, true);
            g.drawString(mc.font, gray, -heartsWidth / 2 + mc.font.width(red), -10, 0xFF3F5A6B, true);
            g.pose().popMatrix();
        }
    }
}
