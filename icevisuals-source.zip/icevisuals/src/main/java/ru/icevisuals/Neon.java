package ru.icevisuals;

import net.minecraft.client.gui.GuiGraphics;

// Мягкое неоновое свечение вокруг прямоугольника
final class Neon {
    static void glow(GuiGraphics g, int x, int y, int w, int h, int color) {
        int rgb = color & 0xFFFFFF;
        for (int i = 4; i >= 1; i--) {
            int c = ((50 - i * 10) << 24) | rgb;
            g.fill(x - i, y - i, x + w + i, y - i + 1, c);
            g.fill(x - i, y + h + i - 1, x + w + i, y + h + i, c);
            g.fill(x - i, y - i + 1, x - i + 1, y + h + i - 1, c);
            g.fill(x + w + i - 1, y - i + 1, x + w + i, y + h + i - 1, c);
        }
    }
}
