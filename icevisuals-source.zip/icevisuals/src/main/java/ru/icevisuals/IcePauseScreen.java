package ru.icevisuals;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

// Своё меню по Esc
public class IcePauseScreen extends Screen {
    private final List<Button> buttons = new ArrayList<>();

    public IcePauseScreen() {
        super(Component.literal("Пауза"));
    }

    @Override
    protected void init() {
        buttons.clear();
        add("Вернуться в игру", 0, () -> minecraft.setScreen(null));
        add("Ice Visuals", 1, () -> minecraft.setScreen(new VisualsScreen(this)));
        add("Настройки", 2, () -> minecraft.setScreen(new OptionsScreen(this, minecraft.options)));
        add("Выйти из мира", 3, () -> minecraft.disconnectFromWorld(ClientLevel.DEFAULT_QUIT_MESSAGE));
    }

    private void add(String text, int index, Runnable action) {
        buttons.add(addWidget(Button.builder(Component.literal(text), b -> action.run())
                .bounds(width / 2 - 100, height / 2 - 46 + index * 28, 200, 24).build()));
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fillGradient(0, 0, width, height, 0xB004101B, 0xD00C2A42);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        var title = Fonts.bold("ICE VISUALS");
        g.drawString(font, title, (width - font.width(title)) / 2, height / 2 - 66, 0xFFA8E6FF, true);
        for (Button b : buttons) {
            boolean over = b.isMouseOver(mouseX, mouseY) || b.isFocused();
            int x = b.getX(), y = b.getY(), w = b.getWidth(), h = b.getHeight();
            int border = over ? 0xFFA8E6FF : 0x608FD0EE;
            if (over) Neon.glow(g, x, y, w, h, 0xA8E6FF);
            g.fill(x + 1, y, x + w - 1, y + h, border);
            g.fill(x, y + 1, x + w, y + h - 1, border);
            g.fill(x + 1, y + 1, x + w - 1, y + h - 1, over ? 0xF01D4663 : 0xE00C1A28);
            var text = Fonts.medium(b.getMessage().getString());
            g.drawString(font, text, x + (w - font.width(text)) / 2, y + 8, 0xFFF2FBFF, false);
        }
    }
}
