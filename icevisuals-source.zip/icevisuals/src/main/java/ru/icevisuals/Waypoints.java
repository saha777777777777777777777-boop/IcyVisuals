package ru.icevisuals;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

final class Waypoints {
    record Point(String name, int x, int y, int z, int color) {}

    // отдельный список для каждого сервера (мира) и измерения
    private static String key() {
        Minecraft mc = Minecraft.getInstance();
        String place = "world";
        if (mc.getCurrentServer() != null) place = mc.getCurrentServer().ip;
        else if (mc.getSingleplayerServer() != null) place = mc.getSingleplayerServer().getWorldData().getLevelName();
        return "points." + place + "." + mc.level.dimension().identifier();
    }

    static List<Point> list() {
        List<Point> result = new ArrayList<>();
        if (Minecraft.getInstance().level == null) return result;
        for (String line : Settings.get(key(), "").split("\n")) {
            String[] p = line.split(";");
            if (p.length != 5) continue;
            result.add(new Point(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2]),
                    Integer.parseInt(p[3]), Integer.parseInt(p[4])));
        }
        return result;
    }

    private static void save(List<Point> points) {
        StringBuilder text = new StringBuilder();
        for (Point p : points) {
            text.append(p.name()).append(';').append(p.x()).append(';').append(p.y()).append(';')
                    .append(p.z()).append(';').append(p.color()).append('\n');
        }
        Settings.set(key(), text.toString());
    }

    static void add(String name, int x, int y, int z) {
        List<Point> points = list();
        String clean = name.replace(";", "").replace("\n", "").trim();
        if (clean.isEmpty()) clean = "Метка " + (points.size() + 1);
        points.add(new Point(clean, x, y, z, Settings.color("points.color")));
        save(points);
    }

    static void remove(int index) {
        List<Point> points = list();
        if (index >= 0 && index < points.size()) points.remove(index);
        save(points);
    }

    // Проекция на экран своими силами, поэтому дальность не ограничена прорисовкой
    static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !Settings.on("points") || !mc.options.getCameraType().isFirstPerson()) return;

        float partial = delta.getGameTimeDeltaPartialTick(true);
        Vec3 eye = mc.player.getEyePosition(partial);
        double yaw = Math.toRadians(mc.player.getViewYRot(partial));
        double pitch = Math.toRadians(mc.player.getViewXRot(partial));
        double sy = Math.sin(yaw), cy = Math.cos(yaw), sp = Math.sin(pitch), cp = Math.cos(pitch);
        double focal = (g.guiHeight() / 2.0) / Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        float scale = Settings.number("points.size", 100) / 100f;

        for (Point p : list()) {
            double dx = p.x() + 0.5 - eye.x, dy = p.y() + 1.0 - eye.y, dz = p.z() + 0.5 - eye.z;
            double depth = -dx * sy * cp - dy * sp + dz * cy * cp;
            if (depth <= 0.1) continue; // метка за спиной
            double right = -dx * cy - dz * sy;
            double up = -dx * sy * sp + dy * cp + dz * cy * sp;
            double screenX = g.guiWidth() / 2.0 + right / depth * focal;
            double screenY = g.guiHeight() / 2.0 - up / depth * focal;
            if (screenX < 0 || screenX > g.guiWidth() || screenY < 0 || screenY > g.guiHeight()) continue;

            var label = Fonts.medium(p.name() + "  " + Math.round(Math.sqrt(dx * dx + dy * dy + dz * dz)) + " м");
            int half = mc.font.width(label) / 2 + 4;
            g.pose().pushMatrix();
            g.pose().translate((float) screenX, (float) screenY);
            g.pose().scale(scale, scale);
            g.fill(-2, -44, 3, -5, 0x30000000 | (p.color() & 0xFFFFFF));
            g.fill(0, -44, 1, -5, p.color());
            for (int i = 0; i < 4; i++) g.fill(-i, i - 4, i + 1, i - 3, p.color());
            for (int i = 0; i < 4; i++) g.fill(-3 + i, i, 4 - i, i + 1, p.color());
            g.fill(-half, 7, half, 20, 0xB00C1A28);
            g.drawString(mc.font, label, -half + 4, 10, p.color(), true);
            g.pose().popMatrix();
        }
    }
}
