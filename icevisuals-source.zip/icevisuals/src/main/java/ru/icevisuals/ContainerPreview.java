package ru.icevisuals;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.BundleContents;
import net.minecraft.world.item.component.ItemContainerContents;
import ru.icevisuals.mixin.HoveredSlotAccessor;

import java.util.ArrayList;
import java.util.List;

// Содержимое шалкера или мешка при наведении курсора
final class ContainerPreview {
    static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (!(screen instanceof AbstractContainerScreen<?>)) return;
            ScreenEvents.afterRender(screen).register((current, g, mouseX, mouseY, delta) -> {
                if (!Settings.on("preview")) return;
                Slot slot = ((HoveredSlotAccessor) current).icevisuals$hoveredSlot();
                if (slot == null || !slot.hasItem()) return;
                List<ItemStack> items = contents(slot.getItem());
                if (!items.isEmpty()) draw(g, slot.getItem(), items, mouseX, mouseY);
            });
        });
    }

    private static List<ItemStack> contents(ItemStack stack) {
        ItemContainerContents container = stack.get(DataComponents.CONTAINER);
        if (container != null) {
            // 27 ячеек, предметы остаются на своих местах
            NonNullList<ItemStack> slots = NonNullList.withSize(27, ItemStack.EMPTY);
            container.copyInto(slots);
            return slots.stream().allMatch(ItemStack::isEmpty) ? List.of() : slots;
        }
        List<ItemStack> result = new ArrayList<>();
        BundleContents bundle = stack.get(DataComponents.BUNDLE_CONTENTS);
        if (bundle != null) bundle.items().forEach(result::add);
        return result;
    }

    private static void draw(GuiGraphics g, ItemStack holder, List<ItemStack> items, int mouseX, int mouseY) {
        Minecraft mc = Minecraft.getInstance();
        float scale = Settings.number("preview.size", 100) / 100f;
        int rows = (items.size() + 8) / 9;
        int w = 9 * 18 + 8;
        int h = rows * 18 + 22;
        // слева от курсора, чтобы не мешала обычная подсказка
        float x = mouseX - w * scale - 8;
        if (x < 2) x = 2;
        float y = Math.max(2, Math.min(mouseY - 10, g.guiHeight() - h * scale - 2));

        g.nextStratum();
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        g.fill(0, 0, w, h, 0xF00C1A28);
        g.fill(0, 0, w, 2, 0xFFA8E6FF);
        g.drawString(mc.font, holder.getHoverName(), 6, 6, 0xFFF2FBFF, false);
        for (int i = 0; i < items.size(); i++) {
            int ix = 4 + (i % 9) * 18;
            int iy = 18 + (i / 9) * 18;
            g.fill(ix, iy, ix + 17, iy + 17, 0xFF142A3E);
            ItemStack item = items.get(i);
            if (item.isEmpty()) continue;
            g.renderItem(item, ix, iy);
            g.renderItemDecorations(mc.font, item, ix, iy);
        }
        g.pose().popMatrix();
    }
}
